# multi_email
sennd multiple mails at the same time
